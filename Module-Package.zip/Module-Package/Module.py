# module & package

# module - single python files consisting of functionality
# package - collection of various modules i.e numpy is package, math is a package, request, twine, build

import DemoPacke.Cal as cal
from Cal import add

print(cal.add(22,33))

print(cal.sub(33,22))

print(cal.mul(2, 3))

print(add(11,33))