def concat(a):
    print(f"This is sting.py concat function")